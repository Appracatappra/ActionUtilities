//
//  ActionUtilities.h
//  ActionUtilities
//
//  Created by Kevin Mullins on 11/30/17.
//  Copyright © 2017 Appracatappra, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ActionUtilities.
FOUNDATION_EXPORT double ActionUtilitiesVersionNumber;

//! Project version string for ActionUtilities.
FOUNDATION_EXPORT const unsigned char ActionUtilitiesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ActionUtilities/PublicHeader.h>


